/*
 * Button.h
 *
 *  Created on: Dec 4, 2023
 *      Author: Administrator
 */

#ifndef __BUTTON_H_
#define __BUTTON_H_
#include "debug.h"
#include "multi_button.h"

enum Button_IDs {
    btn1_id,
    btn2_id,
    btn3_id,
    btn4_id,
    btn5_id,
    btn6_id,
    btn7_id,
    btn8_id,
    btn9_id,
    btn10_id,
    btn11_id,
    btn12_id,
    btn13_id,
    btn14_id,
    btn15_id,
    btn16_id,
    btn17_id,
    btn18_id,
};

//LSW��RSW
#define  LSW_PORT   GPIOA
#define  LSW_PIN    GPIO_Pin_0
#define  RSW_PORT   GPIOA
#define  RSW_PIN    GPIO_Pin_3
//LB��LT��RB��RT
#define  LB_PORT   GPIOB
#define  LB_PIN    GPIO_Pin_9
#define  LT_PORT   GPIOB
#define  LT_PIN    GPIO_Pin_8
#define  RB_PORT   GPIOB
#define  RB_PIN    GPIO_Pin_5
#define  RT_PORT   GPIOB
#define  RT_PIN    GPIO_Pin_4
//BACK��HOME��START
#define  BACK_PORT   GPIOB
#define  BACK_PIN    GPIO_Pin_0
#define  HOME_PORT   GPIOB
#define  HOME_PIN    GPIO_Pin_1
#define  START_PORT  GPIOB
#define  START_PIN   GPIO_Pin_2
//A-BT��B-BT��X-BT��Y-BT
#define  A_BT_PORT   GPIOB
#define  A_BT_PIN    GPIO_Pin_13
#define  B_BT_PORT   GPIOB
#define  B_BT_PIN    GPIO_Pin_14
#define  X_BT_PORT   GPIOB
#define  X_BT_PIN    GPIO_Pin_15
#define  Y_BT_PORT   GPIOA
#define  Y_BT_PIN    GPIO_Pin_8
//GT-A��GT-B��GT-C��GT-D��GT-E
#define  GTA_PORT   GPIOA
#define  GTA_PIN    GPIO_Pin_15
#define  GTB_PORT   GPIOD
#define  GTB_PIN    GPIO_Pin_1
#define  GTC_PORT   GPIOA
#define  GTC_PIN    GPIO_Pin_6
#define  GTD_PORT   GPIOD
#define  GTD_PIN    GPIO_Pin_0
#define  GTE_PORT   GPIOA
#define  GTE_PIN    GPIO_Pin_7


extern void ButtonInit(void);

#endif /* MYBSP_BUTTON_H_ */
