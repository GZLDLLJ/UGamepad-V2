
/**
  ******************************************************************************
 * File Name          : main.c
 * Author             : WCH
 * Version            : V1.0.0
 * Date               : 2021/06/06
 * Description        : Main program body.
*********************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2023 LDSCITECHE Inc.
  * δ���������ɣ��������������κ���;
  * ��������:2023/10/4
  * �汾��V1.0
  * ��Ȩ���У�����ؾ���
  * Copyright(C) �������ܵ��ӿƼ����޹�˾ LDSCITECHE Inc.
  * All rights reserved
  *
  ******************************************************************************
  */
/*
 *@Note
 USART Print debugging routine:
 USART1_Tx(PA9).
This example demonstrates how to use MultiButton to test a key on the evaluation board

*/

#include "debug.h"
#include "Button.h"
#include "Analog.h"
/* Global typedef */

/* Global define */

/* Global Variable */

/*********************************************************************
 * @fn      main
 *
 * @brief   Main program.
 *
 * @return  none
 */
int main(void)
{
    u16 tick=0;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    Delay_Init();
    USART_Printf_Init(115200);
    printf("SystemClk:%d;\r\n", SystemCoreClock);
    ButtonInit();
    ADC_DMA_CONF();
    printf("ADC Debug Demo;\r\n");
    while(1)
    {
        tick++;
        if((tick%100)==0)//500ms
        {
            tick=0;
            printf("\r\n The current ADCH1 value = %d \r\n", ADC_ConvertedValue[0]);
            printf("\r\n The current ADCH2 value = %d \r\n", ADC_ConvertedValue[1]);
            printf("\r\n The current ADCH3 value = %d \r\n", ADC_ConvertedValue[2]);
            printf("\r\n The current ADCH4 value = %d \r\n", ADC_ConvertedValue[3]);
        }
        button_ticks();
        Delay_Ms(5);
    }
}
