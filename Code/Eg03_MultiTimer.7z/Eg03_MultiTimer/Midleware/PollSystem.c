/**
 ******************************************************************************
 * @file           : PollSystem.c
 * @brief          : Poll System
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2022 SYEtronix Inc.
 * δ���������ɣ��������������κ���;
 * ��������:2022/5/4
 * �汾��V1.0
 * ��Ȩ���У�����ؾ���
 * Copyright(C) ������ʤ�������豸���޹�˾ SYEtronix Inc.
 * All rights reserved
 *
 ******************************************************************************
 */

#include "PollSystem.h"
#include "multi_button.h"
#include "MultiTimer.h"
#include "LED.h"
#include "Analog.h"


vu32 uwTick;

MultiTimer timer1;
MultiTimer timer2;
MultiTimer timer3;



void SysTick_Handler(void) __attribute__((interrupt("WCH-Interrupt-fast")));

/*********************************************************************
 * @fn      SYSTICK_Init_Config
 *
 * @brief   SYSTICK_Init_Config.
 *
 * @return  none
 */
void SYSTICK_Init_Config(u64 ticks)
{
    SysTick->SR = 0;
    SysTick->CNT = 0;
    SysTick->CMP = ticks;
    SysTick->CTLR =0xF;

    NVIC_SetPriority(SysTicK_IRQn, 15);
    NVIC_EnableIRQ(SysTicK_IRQn);
}

void SysTick_Handler(void)
{
    SysTick->SR = 0;
    uwTick++;
}

uint64_t PlatformTicksGetFunc(void) {
    return uwTick;
}




void LEDTimer1Callback(MultiTimer* timer, void *userData)
{
    static FlagStatus LedSta=RESET;
    LED(LedSta);
    LedSta=~LedSta;
    printf("LED Status:%d\r\n",LedSta);
    MultiTimerStart(timer, 500, LEDTimer1Callback, userData);
}

void ADCTimer2Callback(MultiTimer* timer, void *userData)
{
    printf("\r\n The current ADCH1 value = %d \r\n", ADC_ConvertedValue[0]);
    printf("\r\n The current ADCH2 value = %d \r\n", ADC_ConvertedValue[1]);
    printf("\r\n The current ADCH3 value = %d \r\n", ADC_ConvertedValue[2]);
    printf("\r\n The current ADCH4 value = %d \r\n", ADC_ConvertedValue[3]);

    MultiTimerStart(timer, 1000, ADCTimer2Callback, userData);
}

void ButtonTimer3Callback(MultiTimer* timer, void *userData)
{
    button_ticks();;
    MultiTimerStart(timer, 5, ButtonTimer3Callback, userData);
}
void PollSystemInit(void) {
    MultiTimerInstall(PlatformTicksGetFunc);
    MultiTimerStart(&timer1, 500, LEDTimer1Callback, NULL);
    MultiTimerStart(&timer2, 1000, ADCTimer2Callback, NULL);
    MultiTimerStart(&timer3, 5, ButtonTimer3Callback, NULL);
    SYSTICK_Init_Config(SystemCoreClock/1000-1);
}

