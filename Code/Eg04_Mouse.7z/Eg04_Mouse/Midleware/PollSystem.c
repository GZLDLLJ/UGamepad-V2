/**
 ******************************************************************************
 * @file           : PollSystem.c
 * @brief          : Poll System
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2022 SYEtronix Inc.
 * δ���������ɣ��������������κ���;
 * ��������:2022/5/4
 * �汾��V1.0
 * ��Ȩ���У�����ؾ���
 * Copyright(C) ������ʤ�������豸���޹�˾ SYEtronix Inc.
 * All rights reserved
 *
 ******************************************************************************
 */

#include "PollSystem.h"
#include "multi_button.h"
#include "MultiTimer.h"
#include "LED.h"
#include "Analog.h"
#include "ch32v20x_usbfs_device.h"

vu32 uwTick;

MultiTimer timer1;
MultiTimer timer2;
MultiTimer timer3;
MultiTimer timer4;


void SysTick_Handler(void) __attribute__((interrupt("WCH-Interrupt-fast")));

/*********************************************************************
 * @fn      SYSTICK_Init_Config
 *
 * @brief   SYSTICK_Init_Config.
 *
 * @return  none
 */
void SYSTICK_Init_Config(u64 ticks)
{
    SysTick->SR = 0;
    SysTick->CNT = 0;
    SysTick->CMP = ticks;
    SysTick->CTLR =0xF;

    NVIC_SetPriority(SysTicK_IRQn, 15);
    NVIC_EnableIRQ(SysTicK_IRQn);
}

void SysTick_Handler(void)
{
    SysTick->SR = 0;
    uwTick++;
}

uint64_t PlatformTicksGetFunc(void) {
    return uwTick;
}




void LEDTimer1Callback(MultiTimer* timer, void *userData)
{
    static FlagStatus LedSta=RESET;
    LED(LedSta);
    LedSta=!LedSta;
    //printf("LED Status:%d\r\n",LedSta);
    MultiTimerStart(timer, 500, LEDTimer1Callback, userData);
}

void ADCTimer2Callback(MultiTimer* timer, void *userData)
{
    static u8 AdcCount=0;
    static u32 A1Sum=0,A2Sum=0,A3Sum=0,A4Sum=0;
    A1Sum+=ADC_ConvertedValue[0];
    A2Sum+=ADC_ConvertedValue[1];
    A3Sum+=ADC_ConvertedValue[2];
    A4Sum+=ADC_ConvertedValue[3];
    AdcCount+=1;
    if(AdcCount==10)
    {
        printf("ADCvalue \t%d \t%d \t%d \t%d\r\n", A1Sum/AdcCount,A2Sum/AdcCount,A3Sum/AdcCount,A4Sum/AdcCount);
        A1Sum=0;
        A2Sum=0;
        A3Sum=0;
        A4Sum=0;
        AdcCount=0;
    }

    MultiTimerStart(timer, 1, ADCTimer2Callback, userData);
}

void ButtonTimer3Callback(MultiTimer* timer, void *userData)
{
    button_ticks();;
    MultiTimerStart(timer, 5, ButtonTimer3Callback, userData);
}

void ReportTimer4Callback(MultiTimer* timer, void *userData)
{
    if( USBFS_DevEnumStatus )
    {


//        if( USBFS_Endp_DataUp( DEF_UEP2, MS_Data_Pack, sizeof( MS_Data_Pack ), DEF_UEP_CPY_LOAD ) == READY )
//        {
//            /* Clear flag after successful loading */
//            flag = 0;
//        }
    }
    MultiTimerStart(timer, 5, ReportTimer4Callback, userData);
}
void PollSystemInit(void) {
    MultiTimerInstall(PlatformTicksGetFunc);
    MultiTimerStart(&timer1, 5, LEDTimer1Callback, NULL);
    MultiTimerStart(&timer2, 10, ADCTimer2Callback, NULL);
    MultiTimerStart(&timer3, 15, ButtonTimer3Callback, NULL);
    MultiTimerStart(&timer4, 20, ReportTimer4Callback, NULL);
    SYSTICK_Init_Config(SystemCoreClock/1000-1);
}

