/**
 ******************************************************************************
 * @file           : PollSystem.c
 * @brief          : Poll System
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2022 SYEtronix Inc.
 * δ���������ɣ��������������κ���;
 * ��������:2022/5/4
 * �汾��V1.0
 * ��Ȩ���У�����ؾ���
 * Copyright(C) ������ʤ�������豸���޹�˾ SYEtronix Inc.
 * All rights reserved
 *
 ******************************************************************************
 */

#include "PollSystem.h"
#include "multi_button.h"
#include "MultiTimer.h"
#include "LED.h"
#include "Analog.h"
#include "ch32v20x_usbfs_device.h"
#include <stdlib.h>


vu32 uwTick;

MultiTimer timer1;
MultiTimer timer2;
MultiTimer timer3;
MultiTimer timer4;

vu8 flag=0;
MouseTypdef  MS_Data_Pack;
                                         // Mouse IN Data Packet
void SysTick_Handler(void) __attribute__((interrupt("WCH-Interrupt-fast")));

/*********************************************************************
 * @fn      SYSTICK_Init_Config
 *
 * @brief   SYSTICK_Init_Config.
 *
 * @return  none
 */
void SYSTICK_Init_Config(u64 ticks)
{
    SysTick->SR = 0;
    SysTick->CNT = 0;
    SysTick->CMP = ticks;
    SysTick->CTLR =0xF;

    NVIC_SetPriority(SysTicK_IRQn, 15);
    NVIC_EnableIRQ(SysTicK_IRQn);
}

void SysTick_Handler(void)
{
    SysTick->SR = 0;
    uwTick++;
}

uint64_t PlatformTicksGetFunc(void) {
    return uwTick;
}




void LEDTimer1Callback(MultiTimer* timer, void *userData)
{
    static FlagStatus LedSta=RESET;
    LED(LedSta);
    LedSta=!LedSta;
    //printf("LED Status:%d\r\n",LedSta);
    MultiTimerStart(timer, 500, LEDTimer1Callback, userData);
}

u32 Map(u32 x, u32 in_min, u32 in_max, u32 out_min, u32 out_max) {
    if(x<=in_min)
    {
        return (u32)out_min;
    }else if(x>=in_max)
    {
        return (u32)out_max;
    }
    return (u32)(((x - in_min) * (out_max - out_min)) / (in_max - in_min) + out_min);
}


void ADCTimer2Callback(MultiTimer* timer, void *userData)
{
    static u8 AdcCount=0;
    static u16 wtick=0;
    static u32 A1Sum=0,A2Sum=0,A3Sum=0,A4Sum=0;
    //u16 xtemp=0,ytemp=0,xtemp1=0,ytemp1=0;
    u16 xtemp=0,ytemp=0,xtemp1=0;//ytemp1=0;

    A1Sum+=ADC_ConvertedValue[0];
    A2Sum+=ADC_ConvertedValue[1];
    A3Sum+=ADC_ConvertedValue[2];
    A4Sum+=ADC_ConvertedValue[3];
    AdcCount+=1;
    if(AdcCount==10)
    {
        //X
        xtemp=Map( A1Sum/AdcCount, 0, 4095, 0, UINT8_MAX );
        ytemp=Map( A2Sum/AdcCount, 0, 4095, 0, UINT8_MAX );

        xtemp1=Map( A3Sum/AdcCount, 0, 4095, 0, UINT8_MAX );
        //ytemp1=Map( A4Sum/AdcCount, 0, 4095, 0, UINT8_MAX );
        //printf("CH: %d %d %d %d\r\n", xtemp,ytemp,xtemp1,ytemp1);
        A1Sum=0;
        A2Sum=0;
        A3Sum=0;
        //A4Sum=0;
        AdcCount=0;

        if(xtemp<(CENTER_X-10))
        {
            MS_Data_Pack.x=-(((CENTER_X-xtemp)>>DIV)+1);
        }else if(xtemp>(CENTER_X+10))
        {
            MS_Data_Pack.x=((xtemp-CENTER_X)>>DIV)+1;;
        }else{
            MS_Data_Pack.x=0;
        }
        if(ytemp<(CENTER_Y-10))
        {
            MS_Data_Pack.y=-(((CENTER_Y-ytemp)>>DIV)+1);
        }else if(ytemp>(CENTER_Y+10))
        {
            MS_Data_Pack.y=((ytemp-CENTER_Y)>>DIV)+1;;
        }else{
            MS_Data_Pack.y=0;
        }
        if(xtemp1<(CENTER_X1-64))
        {
            if(++wtick==5)
            {
                wtick=0;
                MS_Data_Pack.wheel=1;
            }else{
                MS_Data_Pack.wheel=0;
            }

        }else if(xtemp1>(CENTER_X1+64))
        {
            if(++wtick==5)
            {
                wtick=0;
                MS_Data_Pack.wheel=-1;
            }else{
                MS_Data_Pack.wheel=0;
            }
        }else{
            wtick=0;
            MS_Data_Pack.wheel=0;
        }

        //printf("X=%d Y=%d wheel=%d\r\n", MS_Data_Pack.x,MS_Data_Pack.y);
    }

    MultiTimerStart(timer, 1, ADCTimer2Callback, userData);
}

void ButtonTimer3Callback(MultiTimer* timer, void *userData)
{
    button_ticks();
    MultiTimerStart(timer, 5, ButtonTimer3Callback, userData);
}

void ReportTimer4Callback(MultiTimer* timer, void *userData)
{
    static u8 button=0;
    if( USBFS_DevEnumStatus )
    {


            if((MS_Data_Pack.x!=0)||(MS_Data_Pack.y!=0)||(MS_Data_Pack.wheel!=0)||(MS_Data_Pack.button!=button))
            {
                if( USBFS_Endp_DataUp( DEF_UEP1, (u8*)&MS_Data_Pack, sizeof( MS_Data_Pack ), DEF_UEP_CPY_LOAD ) == READY )
                {
                    /* Clear flag after successful loading */

                }
                button=MS_Data_Pack.button;
            }


    }
    MultiTimerStart(timer, 5, ReportTimer4Callback, userData);
}
void PollSystemInit(void) {
    MultiTimerInstall(PlatformTicksGetFunc);
    MultiTimerStart(&timer1, 5, LEDTimer1Callback, NULL);
    MultiTimerStart(&timer2, 10, ADCTimer2Callback, NULL);
    MultiTimerStart(&timer3, 15, ButtonTimer3Callback, NULL);
    MultiTimerStart(&timer4, 20, ReportTimer4Callback, NULL);
    SYSTICK_Init_Config(SystemCoreClock/1000-1);
}

