/*
 * Button.h
 *
 *  Created on: Dec 4, 2023
 *      Author: Administrator
 */

#ifndef __ANALOG_H_
#define __ANALOG_H_
#include "debug.h"

#define  LENGTH   4

extern u16 ADC_ConvertedValue[LENGTH];
extern void adc_Init(void);

extern void DMA_Tx_Init(void);

extern void ADC_DMA_CONF(void);


#endif /* MYBSP_BUTTON_H_ */
