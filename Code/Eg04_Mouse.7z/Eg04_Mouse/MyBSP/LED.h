/*
 * LED.h
 *
 *  Created on: Dec 14, 2023
 *      Author: lijinl
 */

#ifndef MYBSP_LED_H_
#define MYBSP_LED_H_

#include "debug.h"

#define     LED(x)      (x?GPIO_ResetBits(GPIOB,GPIO_Pin_3):GPIO_SetBits(GPIOB,GPIO_Pin_3))

extern void LED_Init(void);

#endif /* MYBSP_LED_H_ */
